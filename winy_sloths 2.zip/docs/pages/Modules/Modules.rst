===========
Modules
===========

.. toctree::
   :maxdepth: 4

This explains everything.

strategy_file.py
--------------------

.. include:: strategy_file.rst

constants.py
--------------------

.. include:: constants.rst

winy_sloth.py
--------------------

.. include:: winy_sloth.rst

crypto_exchange_platform.py
---------------------------

.. include:: crypto_exchange_platform.rst

errors.py
--------------------

.. include:: errors.rst