strategy\_file module
=====================

.. automodule:: strategy_file
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
