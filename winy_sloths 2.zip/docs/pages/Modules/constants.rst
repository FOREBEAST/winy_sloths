constants module
================

.. automodule:: constants
   :members:
   :undoc-members:
   :show-inheritance:
   :noindex:
