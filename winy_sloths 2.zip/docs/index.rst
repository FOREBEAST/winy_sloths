=======================================
Documentation Winy Sloths
=======================================

Ce document contient la documentation officielle du projet winy_sloths. Ce projet est hébergé sur Github à l'adresse suivante: https://github.com/Xispa33/winy_sloths

.. toctree::
   :caption: Table des matières
   :maxdepth: 2
   :numbered:

   pages/General
   pages/CI
   pages/Tests
   pages/Modules/Modules
   pages/Licence

.. note:: This is a note.

.. warning:: This is a warning.

.. important:: This is important.
