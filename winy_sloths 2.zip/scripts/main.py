#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
from winy_sloth import *

if __name__ == "__main__":
    
    main_obj = WinySloth()
    main_obj.run()